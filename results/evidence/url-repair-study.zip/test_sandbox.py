import json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from sandbox import run,validate_tree
class IsolationTests(unittest.TestCase):
 def test_python_can_use_pytest_but_cannot_access_host_or_network(self):
  with tempfile.TemporaryDirectory() as directory:
   code='''import pathlib,socket,json,pytest
outside=['/home/khushidiwan/Documents/Codex/2026-11-15/https-github-com-hydra-db-selfgraph/work/worker-credentials.json','/home/khushidiwan/.agents/skills/box/sandbox/hydradb-hack/work/next-repair-design/3140/fixed/httpx/_urlparse.py','/etc/passwd']
assert not any(pathlib.Path(x).exists() for x in outside)
pathlib.Path('/checkout/written').write_text('local')
s=socket.socket();s.settimeout(.2)
try:s.connect(('1.1.1.1',443));raise AssertionError('network available')
except OSError:pass
print('isolated')'''
   p=run(directory,['python','-c',code],capture_output=True,text=True,timeout=10)
   self.assertEqual(p.returncode,0,p.stderr);self.assertIn('isolated',p.stdout);self.assertTrue((Path(directory)/'written').exists())
 def test_symlink_is_rejected_after_sandbox_execution(self):
  with tempfile.TemporaryDirectory() as directory:
   p=run(directory,['python','-c',"import pathlib;pathlib.Path('/checkout/escape.py').symlink_to('/etc/passwd')"],capture_output=True,timeout=10)
   self.assertEqual(p.returncode,0)
   with self.assertRaisesRegex(ValueError,'nonregular'):validate_tree(directory)
 def test_evaluator_source_is_readonly_and_only_results_writable(self):
  with tempfile.TemporaryDirectory() as directory,tempfile.TemporaryDirectory() as results:
   p=run(directory,['python','-c',"import pathlib;pathlib.Path('/results/ok').write_text('ok');pathlib.Path('/checkout/tamper').write_text('bad')"],readonly=True,results=results,capture_output=True,timeout=10)
   self.assertNotEqual(p.returncode,0);self.assertTrue((Path(results)/'ok').exists());self.assertFalse((Path(directory)/'tamper').exists())
if __name__=='__main__':unittest.main()
