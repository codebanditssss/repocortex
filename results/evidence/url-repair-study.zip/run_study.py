"""Restricted, paired historical repair pilot. Evaluator-only hidden tests."""
from __future__ import annotations
import dataclasses,difflib,hashlib,io,json,os,re,shutil,subprocess,sys,tarfile,time,urllib.request,urllib.error,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'scripts'))
from repair_transport import make_send,run_bounded_chat
from sandbox import run as sandbox_run,validate_tree
STUDY=Path(__file__).resolve().parent
ART=STUDY/'artifacts';ART.mkdir(exist_ok=True)
SOURCE=ROOT/'work/transfer/httpx'
CANDIDATES=json.loads((STUDY/'cases.json').read_text()) if (STUDY/'cases.json').exists() else []
MODEL='openai/gpt-5.6-luna'
BUDGET={'elapsed_s':600,'input_tokens':200000,'output_tokens':48000,'model_calls':24}
SYSTEM='''You are repairing the HTTPX library in an isolated historical source snapshot. Implement the requested behavior with minimal product-code edits. No internet, git, shell, or external filesystem tools are available. Read/search/list are limited to this checkout; edit only httpx/*.py product files. Do not change tests or configuration. You can run the existing test module with run_tests. Hidden regression tests are evaluated independently after you finish. If locate_bug is available, it supplies candidate functions and structural paths from this exact base snapshot with its configured past-fix history; never a known answer or future fix. Both arms start with a mandatory initial lookup supplied below; additional lookups are optional. Existing parent tests can assert behavior superseded by the requested specification; hidden evaluator tests define the requested behavior. Call finish when done. You have at most24 model calls,48000 output tokens,200000 input tokens and600 seconds; act efficiently. Once the cause is clear, make the minimal repair rather than continuing redundant reads.'''
def tool(name,description,properties,required=()):
 return {'type':'function','function':{'name':name,'description':description,'parameters':{'type':'object','properties':properties,'required':list(required),'additionalProperties':False}}}
STRING={'type':'string'}
TOOLS=[tool('list_files','List checkout file paths, optionally filter by substring.',{'contains':STRING}),tool('read_file','Read up to160 numbered lines from one checkout file.',{'path':STRING,'start':{'type':'integer'},'end':{'type':'integer'}},['path']),tool('search_code','Literal text search across Python product/test files, max30 matches.',{'text':STRING},['text']),tool('replace_text','Replace exactly one literal occurrence in a product Python file. No tests/config edits.',{'path':STRING,'old':STRING,'new':STRING},['path','old','new']),tool('run_tests','Run the existing test module for this task (no hidden regression tests).',{}),tool('finish','Declare the repair complete.',{'summary':STRING},['summary'])]
LOCATE=tool('locate_bug','RepoCortex hybrid ranking. Returns top5 candidate functions and structural evidence from task-base source with configured history. No future-fix data.',{'report':STRING},['report'])
def sha(b):return hashlib.sha256(b).hexdigest()
def write_json(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2))
def ref(p):return {'path':str(p.relative_to(ART)),'sha256':sha(p.read_bytes())}
def archive(commit,path):
 path.mkdir(parents=True,exist_ok=False)
 raw=subprocess.check_output(['git','archive',commit],cwd=SOURCE)
 with tarfile.open(fileobj=io.BytesIO(raw)) as tar:tar.extractall(path,filter='data')
def clean_env(env_name):
 return {'PATH':str(STUDY/env_name/'bin')+':/usr/bin:/bin','LANG':'C.UTF-8','PYTHONHASHSEED':'0','PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
def specs(case):
 return [{'test_id':'upstream_modules','argv':['python','-m','pytest','-p','anyio.pytest_plugin','-p','no:cacheprovider','-q',*case['test_modules'],'--junitxml=/results/upstream.xml'],'cwd':'.','timeout_s':60,'expected_before':'fail'}]
def evaluate(case,checkout,run_dir,phase):
 validate_tree(checkout)
 dest=run_dir/('evaluate-'+phase);shutil.copytree(checkout,dest,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
 patch=(STUDY/'inputs'/case['task_id']/'upstream-tests.patch').read_bytes()
 apply=subprocess.run(['patch','-p1','--batch','--forward'],input=patch,cwd=dest,capture_output=True)
 if apply.returncode:raise RuntimeError('hidden_test_patch_failed')
 results_dir=run_dir/('test-results-'+phase);results_dir.mkdir()
 spec=specs(case)[0];start=time.monotonic();timed=False
 try:
  proc=sandbox_run(dest,spec['argv'],readonly=True,results=results_dir,capture_output=True,timeout=60)
  output=proc.stdout+proc.stderr;code=proc.returncode
 except subprocess.TimeoutExpired as exc:output=(exc.stdout or b'')+(exc.stderr or b'');code=None;timed=True
 validate_tree(results_dir)
 elapsed=time.monotonic()-start;log=run_dir/f'{phase}-upstream.log';log.write_bytes(output)
 xml=results_dir/'upstream.xml';junit=None;cases={}
 if xml.exists():
  saved=run_dir/f'{phase}-upstream.xml';shutil.copyfile(xml,saved);junit=ref(saved)
  for c in ET.parse(xml).iter('testcase'):
   name=c.get('classname','')+'::'+c.get('name','')
   if name in cases:raise RuntimeError('duplicate_testcase')
   cases[name]='error' if c.find('error') is not None else 'fail' if c.find('failure') is not None else 'skip' if c.find('skipped') is not None else 'pass'
 expected=set(case['expected_case_ids']);present=set(cases)
 regression=set(case['regression_case_ids']);guards=expected-regression
 return [{'test_id':'upstream_modules','phase':phase,'argv':spec['argv'],'cwd':'.','timeout_s':60,'elapsed_s':elapsed,'exit_code':code,'timed_out':timed,'output':ref(log),'junit':junit,'cases':cases,'case_set_matches':present==expected,'regression_pass':bool(regression) and all(cases.get(x)=='pass' for x in regression),'guards_pass':all(cases.get(x)=='pass' for x in guards)}]

def run_agent(case,arm,ranker,manifest,key):
 tid=case['task_id'];checkout=STUDY/tid/arm;run_dir=ART/f'{tid}-{arm}';run_dir.mkdir()
 protected_before={str(p.relative_to(checkout)):sha(p.read_bytes()) for p in checkout.rglob('*') if p.is_file() and not (p.is_relative_to(checkout/'httpx') and p.suffix=='.py')}
 started=time.monotonic();commands=evaluate(case,checkout,run_dir,'before')
 prompt=(STUDY/tid/'prompt.txt').read_text();messages=[{'role':'system','content':SYSTEM},{'role':'user','content':prompt}]
 tools=TOOLS+[LOCATE];transcript=[];usage=[];raw_usage=[];locate_calls=0;errors=[];status='budget_exhausted';agent_start=time.monotonic();finished=False
 def path(value):
  p=(checkout/value).resolve()
  if not p.is_relative_to(checkout.resolve()) or any(part.startswith('.') for part in Path(value).parts):raise ValueError('path_not_allowed')
  return p
 def execute(name,args):
  nonlocal locate_calls,finished
  validate_tree(checkout)
  if name=='list_files':return [str(p.relative_to(checkout)) for p in sorted(checkout.rglob('*')) if p.is_file() and not any(part.startswith('.') for part in p.relative_to(checkout).parts) and args.get('contains','') in str(p.relative_to(checkout))][:120]
  if name=='read_file':
   p=path(args['path']);lines=p.read_text().splitlines();start=max(1,int(args.get('start',1)));end=min(start+159,int(args.get('end',start+159)))
   return '\n'.join(f'{i+1}: {lines[i]}' for i in range(start-1,min(end,len(lines))))
  if name=='search_code':
   text=args['text'].lower();out=[]
   for directory in ['httpx','tests']:
    for p in sorted((checkout/directory).rglob('*.py')):
     for number,line in enumerate(path(str(p.relative_to(checkout))).read_text().splitlines(),1):
      if text in line.lower():out.append(f'{p.relative_to(checkout)}:{number}: {line[:240]}')
      if len(out)>=30:return out
   return out
  if name=='replace_text':
   p=path(args['path'])
   if not p.is_relative_to(checkout/'httpx') or p.suffix!='.py' or p.is_symlink():raise ValueError('only_product_python_edits')
   old=args['old'];text=p.read_text()
   if not old or text.count(old)!=1:raise ValueError('replacement_must_match_exactly_once')
   p.write_text(text.replace(old,args['new'],1));return 'replaced'
  if name=='run_tests':
   proc=sandbox_run(checkout,['python','-m','pytest','-p','anyio.pytest_plugin','-p','no:cacheprovider','-q',*case['test_modules']],capture_output=True,text=True,timeout=25)
   validate_tree(checkout)
   return {'exit_code':proc.returncode,'output':(proc.stdout+proc.stderr)[-3500:]}
  if name=='locate_bug':
   from repocortex.serve.load import locate
   locate_calls+=1;return {'snapshot':'exact task-base source with preregistered historical state','hits':locate(ranker,args['report'],5)}
  if name=='finish':finished=True;return ('finished','submitted')
  raise ValueError('tool_not_allowed')
 initial=[]
 if arm in ['frozen','learned']:
  initial_start=time.monotonic();result=execute('locate_bug',{'report':prompt})
  initial=[{'event':'mandatory_initial_locate','query':prompt,'elapsed_s':time.monotonic()-initial_start,'tool_results':[{'name':'locate_bug','result':result}]}]
  messages.append({'role':'user','content':'Mandatory initial RepoCortex lookup: '+json.dumps(result)})
 progress=list(initial)
 def persist(entry):
  progress.append(entry)
  write_json(run_dir/'transcript-progress.json',progress)
  print(tid,arm,'turn',entry['turn']+1,'outcome',entry['outcome'],flush=True)
 loop=run_bounded_chat(make_send('https://api.gmi-serving.com/v1/chat/completions',key),
  {'model':MODEL,'tools':tools,'tool_choice':'auto','temperature':0},messages,execute,
  budget=BUDGET,started=started,max_tokens_per_call=4096,secrets=(key,),request_prefix=tid+'-'+arm,on_turn=persist)
 transcript=initial+loop['transcript'];errors=loop['errors'];stop_reason=loop['status']
 status={'model_stopped':'completed','empty_response':'error','length_truncated':'error'}.get(stop_reason,stop_reason)
 write_json(run_dir/'requests.json',loop['requests'])
 for request in loop['requests']:
  raw=request['usage'] or {};raw_usage.append(raw)
  prompt_tokens=raw.get('prompt_tokens');cached=(raw.get('prompt_tokens_details') or {}).get('cached_tokens')
  usage.append({'request_id':request['request_id'],'input_uncached':prompt_tokens-cached if isinstance(prompt_tokens,int) and isinstance(cached,int) else None,'input_cache_read':cached if isinstance(cached,int) else None,'input_cache_write':0 if isinstance(cached,int) else None,'output':raw.get('completion_tokens')})
 agent_elapsed=time.monotonic()-agent_start
 validate_tree(checkout)
 protected_after={str(p.relative_to(checkout)):sha(p.read_bytes()) for p in checkout.rglob('*') if p.is_file() and not (p.is_relative_to(checkout/'httpx') and p.suffix=='.py') and not any(x in {'.pytest_cache','__pycache__'} for x in p.relative_to(checkout).parts)}
 protected_original={k:v for k,v in protected_before.items() if not any(x in {'.pytest_cache','__pycache__'} for x in Path(k).parts)}
 protected_unchanged=protected_original==protected_after
 write_json(run_dir/'protected-files.json',{'before':protected_original,'after':protected_after,'unchanged':protected_unchanged})
 if not protected_unchanged:errors.append({'kind':'integrity','code':'nonproduct_files_modified'})
 commands+=evaluate(case,checkout,run_dir,'after')
 patch=[]
 # Compare product bytes to original base snapshot, never to the fix revision.
 for p in sorted((checkout/'httpx').rglob('*.py')):
  rel=str(p.relative_to(checkout));before=subprocess.check_output(['git','show',case['base_commit']+':'+rel],cwd=SOURCE).decode();after=p.read_text()
  if before!=after:
   patch.append('diff --git a/'+rel+' b/'+rel+'\n');patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 patchpath=run_dir/'fix.diff';patchpath.write_text(''.join(patch));write_json(run_dir/'usage.json',{'calls':usage});write_json(run_dir/'transcript.json',transcript);write_json(run_dir/'usage-raw.json',raw_usage)
 if not errors and status!='completed':errors.append({'kind':'agent','code':'unfinished'})
 receipt={'schema_version':'learning-repair-1','experiment_id':manifest['experiment_id'],'task_id':tid,'arm':arm,'run_id':tid+'-'+arm,'protocol':manifest['protocol'],'checkout':{'checkout_id':tid+'-'+arm,'repository':case['repository'],'base_commit':case['base_commit'],'clean_start':True,'isolated':True},'prompt_sha256':sha(prompt.encode()),'tools':[x['function']['name'] for x in tools],'locate_bug_calls':locate_calls,'status':status,'protected_files_unchanged':protected_unchanged,'elapsed_s':time.monotonic()-started,'errors':errors,'transcript':ref(run_dir/'transcript.json'),'patch':ref(patchpath) if patch else None,'usage':ref(run_dir/'usage.json'),'commands':commands}
 write_json(run_dir/'receipt.json',receipt)
 observation={'task':tid,'arm':arm,'status':status,'agent_elapsed_s':agent_elapsed,'total_elapsed_s':receipt['elapsed_s'],'stop_reason':stop_reason,'model_calls':len(usage),'locate_calls':locate_calls,'provider_reported_input_total':sum(u.get('prompt_tokens',0) for u in raw_usage),'provider_reported_output_total':sum(u.get('completion_tokens',0) for u in raw_usage),'after_exit_codes':[c['exit_code'] for c in commands if c['phase']=='after'],'patch_bytes':patchpath.stat().st_size,'errors':errors}
 write_json(run_dir/'observation.json',observation);print('RESULT',json.dumps(observation),flush=True)
 return receipt,observation

if __name__=='__main__':
 from study_setup import cli
 cli(sys.modules[__name__])
