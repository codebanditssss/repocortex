import tempfile
import unittest
from pathlib import Path
import validate as v

class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.xml=self.root/'test.xml'
    def test_real_junit_children_override_summary_claim(self):
        self.xml.write_text('<testsuite tests="999" failures="0"><testcase classname="x" name="a"><failure/></testcase><testcase classname="x" name="b"/></testsuite>')
        self.assertEqual(v.junit(self.xml),{'x::a':'fail','x::b':'pass'})
    def test_duplicate_junit_rejected(self):
        self.xml.write_text('<testsuite><testcase classname="x" name="a"/><testcase classname="x" name="a"/></testsuite>')
        with self.assertRaisesRegex(ValueError,'duplicate'):v.junit(self.xml)
    def test_empty_junit_rejected(self):
        self.xml.write_text('<testsuite tests="5"/>')
        with self.assertRaisesRegex(ValueError,'empty'):v.junit(self.xml)
    def test_artifact_tamper_rejected(self):
        self.xml.write_text('original');ref={'path':'test.xml','sha256':v.sha(self.xml)};self.xml.write_text('changed')
        with self.assertRaisesRegex(ValueError,'hash mismatch'):v.reference(self.root,ref)
    def test_escape_rejected(self):
        with self.assertRaisesRegex(ValueError,'escapes'):v.confined(self.root,'../private')
    def test_unknown_usage_not_zero(self):
        result=v.usage_summary([{'request_id':'a','turn':0,'attempted':True,'usage':None}],{'model_calls':2,'input_tokens':5,'output_tokens':5})
        self.assertEqual(len(result['unknown_usage']),2)
    def test_overshoot_detected(self):
        result=v.usage_summary([{'request_id':'a','turn':0,'attempted':True,'usage':{'prompt_tokens':6,'completion_tokens':1}}],{'model_calls':2,'input_tokens':5,'output_tokens':5})
        self.assertTrue(result['token_or_call_budget_exceeded'])
    def test_retry_or_gap_rejected(self):
        rows=[{'request_id':'a','turn':0,'attempted':True,'usage':None}]*2
        with self.assertRaisesRegex(ValueError,'duplicate'):v.usage_summary(rows,{})
    def test_false_pass_flag_rejected(self):
        self.xml.write_text('<testsuite><testcase classname="x" name="a"><failure/></testcase><testcase classname="x" name="b"/></testsuite>')
        log=self.root/'test.log';log.write_text('run')
        command={'phase':'before','output':{'path':'test.log','sha256':v.sha(log)},'junit':{'path':'test.xml','sha256':v.sha(self.xml)},'cases':{'x::a':'fail','x::b':'pass'},'case_set_matches':True,'regression_pass':True,'guards_pass':True,'timed_out':False,'exit_code':1}
        case={'expected_case_ids':['x::a','x::b'],'regression_case_ids':['x::a']}
        with self.assertRaisesRegex(ValueError,'false regression'):v.check_test(self.root,command,case,'before')
        command['regression_pass']=False
        self.assertEqual(v.check_test(self.root,command,case,'before')['guards'],1)
        command['cases']['x::a']='pass'
        with self.assertRaisesRegex(ValueError,'differ from JUnit'):v.check_test(self.root,command,case,'before')

if __name__=='__main__':unittest.main()
