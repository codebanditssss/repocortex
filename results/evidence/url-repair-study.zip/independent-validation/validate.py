"""Independent read-only evidence validation; never imports the experiment harness."""
import argparse
import hashlib
import io
import tarfile
import json
import subprocess
import stat
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def confined(root, name):
    path = (root / name).resolve()
    require(path.is_relative_to(root.resolve()), 'artifact path escapes root')
    return path


def reference(root, ref):
    require(isinstance(ref, dict), 'missing artifact reference')
    path = confined(root, ref['path'])
    require(sha(path) == ref['sha256'], 'artifact hash mismatch: ' + ref['path'])
    return path


def junit(path):
    cases = {}
    for node in ET.parse(path).iter('testcase'):
        name = node.get('classname', '') + '::' + node.get('name', '')
        require(name not in cases, 'duplicate JUnit case')
        cases[name] = ('error' if node.find('error') is not None else 'fail' if node.find('failure') is not None
                       else 'skip' if node.find('skipped') is not None else 'pass')
    require(bool(cases), 'empty JUnit')
    return cases


def check_test(art, command, case, phase):
    require(command['phase'] == phase, 'test phase mismatch')
    reference(art, command['output'])
    actual = junit(reference(art, command['junit']))
    require(actual == command['cases'], 'claimed test outcomes differ from JUnit')
    expected, regressions = set(case['expected_case_ids']), set(case['regression_case_ids'])
    require(regressions and regressions <= expected, 'invalid registered regression set')
    require(set(actual) == expected, 'JUnit case set differs from registration')
    require(command['case_set_matches'] is True, 'claimed case set mismatch')
    passed = lambda names: all(actual[x] == 'pass' for x in names)
    require(command['regression_pass'] == passed(regressions), 'false regression pass flag')
    require(command['guards_pass'] == passed(expected - regressions), 'false guard pass flag')
    require(not command['timed_out'], 'test timeout')
    require(command['exit_code'] == (0 if passed(expected) else 1), 'test exit inconsistent with JUnit')
    if phase == 'before':
        require(not passed(regressions) and passed(expected - regressions), 'baseline not isolated regression failure')
    return {'total': len(actual), 'regressions': len(regressions), 'guards': len(expected - regressions),
            'passed': sum(v == 'pass' for v in actual.values()), 'failed': sum(v in ('fail', 'error') for v in actual.values()),
            'all_pass': passed(expected)}


def usage_summary(requests, budget):
    ids = [r['request_id'] for r in requests]
    require(len(ids) == len(set(ids)), 'duplicate request / retry identifier')
    require([r['turn'] for r in requests] == list(range(len(requests))), 'request turn gap or retry')
    require(all(r.get('attempted') is True for r in requests), 'unrecorded attempt')
    unknown = []
    totals = {'prompt_tokens': 0, 'completion_tokens': 0}
    for row in requests:
        usage = row.get('usage')
        for field in totals:
            value = usage.get(field) if isinstance(usage, dict) else None
            if type(value) is not int or value < 0:
                unknown.append({'request_id': row['request_id'], 'field': field})
            else:
                totals[field] += value
    exceeded = (len(requests) > budget['model_calls'] or totals['prompt_tokens'] > budget['input_tokens']
                or totals['completion_tokens'] > budget['output_tokens'])
    return {'model_calls': len(requests), 'known_token_totals': totals, 'unknown_usage': unknown, 'token_or_call_budget_exceeded': exceeded}


def validate(study, registration_only=False):
    art = study / 'artifacts'
    manifest = load(study / 'manifest.json')
    protocol = manifest['protocol']
    errors, rows = [], []
    def check(label, fn):
        try:
            return fn()
        except Exception as exc:
            errors.append({'check': label, 'error': str(exc)})
    for name, digest in manifest['files'].items():
        check('registered:' + name, lambda n=name, d=digest: require(sha(confined(study, n)) == d, 'registered hash mismatch'))
    repo = study.parents[1]
    source = repo / 'work/transfer/httpx'
    freeze = load(study / 'source-freeze.json')
    require(sha(study / 'source-before-trial.zip') == freeze['archive_sha256'], 'source archive hash mismatch')
    with zipfile.ZipFile(study / 'source-before-trial.zip') as archive:
        for name, digest in freeze['files'].items():
            check('source:' + name, lambda n=name, d=digest: require(hashlib.sha256(archive.read(n)).hexdigest() == d, 'source entry mismatch'))
    for name, digest in freeze['files'].items():
        check('source-commit:' + name, lambda n=name, d=digest: require(
            hashlib.sha256(subprocess.check_output(['git','show',freeze['revision']+':'+n],cwd=repo)).hexdigest()==d,
            'source archive differs from registered commit'))
    require(load(study / 'config.json') == protocol, 'config/protocol mismatch')
    require(load(study / 'cases.json') == manifest['tasks'], 'case manifest mismatch')
    expected = [(c['task_id'], arm) for c in manifest['tasks'] for arm in ('frozen', 'learned')]
    require(sorted(map(tuple, protocol['order'])) == sorted(expected), 'registered order does not contain each pair once')
    for case in manifest['tasks']:
        tid = case['task_id']; directory = study / tid
        check(tid + ':prompt', lambda: require(sha(directory / 'prompt.txt') == case['prompt_sha256'] == sha(study / 'inputs' / tid / 'prompt.txt'), 'prompt mismatch'))
        base = load(directory / 'base-snapshot.json')
        require(base['base_commit'] == case['base_commit'], 'snapshot base mismatch')
        raw = subprocess.check_output(['git','archive',case['base_commit']],cwd=source)
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            actual_base = {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive if m.isfile()}
        require(actual_base == base['source_hashes'], 'registered base snapshot differs from git source')
        for phase in ('parent','fixed'):
            admission=art/(tid+'-admission-'+phase)
            commands=load(admission/'check.json')
            require(len(commands)==1,'invalid admission commands')
            result=check_test(art,commands[0],case,'verification')
            if phase=='parent':
                require(not commands[0]['regression_pass'] and commands[0]['guards_pass'],'admission parent failure not isolated')
            else:
                require(result['all_pass'],'upstream fixed admission did not pass')
        history = load(directory / 'training.json')
        require(history['base_commit'] == case['base_commit'], 'history base mismatch')
        entries = history['training']
        require(len(entries) >= 20, 'insufficient registered history')
        require([(r['time'], r['commit']) for r in entries] == sorted((r['time'], r['commit']) for r in entries), 'history not chronological')
        require(all(r['time'] < history['base_timestamp'] for r in entries), 'future history')
        require(len({r['commit'] for r in entries}) == len(entries), 'duplicate history commit')
        for entry in entries:
            def history_entry(r=entry):
                require(subprocess.run(['git','merge-base','--is-ancestor',r['commit'],case['base_commit']],cwd=source,capture_output=True).returncode==0,'history not ancestor')
                raw=subprocess.check_output(['git','show','-s','--format=%ct%x00%B',r['commit']],cwd=source).decode()
                stamp,message=raw.split('\0',1);message=message.strip()
                require(int(stamp)==r['time'],'history timestamp mismatch')
                require(r['summary']==message.splitlines()[0] and r['description']=='\n'.join(message.splitlines()[1:]),'history text differs from immutable commit')
            check(tid+':history:'+entry['commit'],history_entry)
        for arm in ('frozen', 'learned'):
            check(tid + ':' + arm + ':state', lambda a=arm: require(sha(directory / (a + '-state.json')) == protocol['states'][tid + '-' + a], 'state hash mismatch'))
    if registration_only:
        return {'valid': not errors, 'phase': 'registration', 'errors': errors, 'attempts': []}
    launch = load(study / 'launch.json')
    require(launch['manifest_sha256'] == sha(study / 'manifest.json'), 'manifest changed since launch')
    require(launch['attempts'] == len(expected), 'launch attempt count mismatch')
    require(manifest['registered_at_utc'] <= launch['started_at_utc'], 'launch predates registration')
    receipts = load(study / 'receipts.json')['receipts']
    require([(r['task_id'], r['arm']) for r in receipts] == list(map(tuple, protocol['order'])), 'missing, extra, retried or reordered attempts')
    tools = [t['function']['name'] for t in protocol['tools']]
    model_sets = {}
    for receipt in receipts:
        tid, arm = receipt['task_id'], receipt['arm']; run = art / (tid + '-' + arm)
        case = next(c for c in manifest['tasks'] if c['task_id'] == tid)
        row = {'task': tid, 'arm': arm, 'status': receipt['status'], 'compliant_repair': False}
        rows.append(row)
        if receipt['status'] == 'harness_error':
            require(load(run / 'terminal-error.json') == receipt, 'missing retained terminal failure')
            row['classification'] = 'harness_error_usage_unknown'
            continue
        def attempt():
            require(load(run / 'receipt.json') == receipt, 'aggregated receipt differs')
            require(receipt['protocol'] == protocol, 'paired protocol/tool/budget/model mismatch')
            require(receipt['tools'] == tools, 'tool mismatch')
            require(receipt['prompt_sha256'] == case['prompt_sha256'], 'receipt prompt mismatch')
            require(receipt['checkout']['base_commit'] == case['base_commit'], 'checkout revision mismatch')
            protected = load(run / 'protected-files.json')
            baseline = load(study / tid / 'base-snapshot.json')['source_hashes']
            expected_protected = {k:v for k,v in baseline.items() if not (k.startswith('httpx/') and k.endswith('.py'))}
            require(protected['before'] == expected_protected == protected['after'], 'protected files changed or incomplete baseline')
            require(receipt['protected_files_unchanged'] and protected['unchanged'], 'protected change flag')
            for p in (study/tid/arm).rglob('*'):
                require(stat.S_ISREG(p.lstat().st_mode) or stat.S_ISDIR(p.lstat().st_mode), 'nonregular checkout entry')
            current = {str(p.relative_to(study/tid/arm)):sha(p) for p in (study/tid/arm).rglob('*') if p.is_file()
                       and not (p.is_relative_to(study/tid/arm/'httpx') and p.suffix == '.py')
                       and not any(x in ('.pytest_cache','__pycache__') for x in p.relative_to(study/tid/arm).parts)}
            require(current == expected_protected, 'checkout protected bytes differ')
            transcript = load(reference(art, receipt['transcript']))
            require(transcript and transcript[0]['event'] == 'mandatory_initial_locate', 'missing mandatory first lookup')
            require(transcript[0]['query'] == (study/tid/'prompt.txt').read_text(), 'initial lookup query mismatch')
            require(len(transcript[0]['tool_results'][0]['result']['hits']) <= 5, 'initial lookup exceeds registered cap')
            requests = load(run / 'requests.json')
            require([e['request_id'] for e in transcript[1:]] == [r['request_id'] for r in requests], 'missing request transcript')
            require(receipt['locate_bug_calls'] == sum(t['name']=='locate_bug' for e in transcript for t in e.get('tool_results',[])), 'lookup count mismatch')
            model_sets[(tid, arm)] = sorted({e['response_model'] for e in transcript if e.get('response_model')})
            if receipt['patch']:
                reference(art, receipt['patch'])
            reference(art, receipt['usage'])
            commands = receipt['commands']
            require(len(commands) == 2, 'expected before and after evaluation')
            row['before'] = check_test(art, commands[0], case, 'before')
            row['after'] = check_test(art, commands[1], case, 'after')
            row.update(usage_summary(requests, protocol['budget']))
            row['wall_budget_exceeded'] = receipt['elapsed_s'] > protocol['budget']['elapsed_s']
            provider_error = any(r.get('outcome') in ('http_error','transport_error','malformed','null_content','empty_content','length') for r in requests)
            row['classification'] = ('provider_error' if provider_error else 'usage_unknown' if row['unknown_usage'] else 'budget_exceeded'
                                     if row['token_or_call_budget_exceeded'] or row['wall_budget_exceeded'] else receipt['status'])
            row['compliant_repair'] = bool(row['after']['all_pass'] and receipt['status']=='completed' and not receipt['errors']
                                          and row['classification']=='completed')
        check(tid + ':' + arm, attempt)
    for case in manifest['tasks']:
        tid = case['task_id']; pair = [model_sets.get((tid, a)) for a in ('frozen','learned')]
        if all(pair):
            check(tid + ':models', lambda: require(pair[0] == pair[1], 'paired response models differ'))
    return {'valid': not errors, 'phase':'outcomes', 'errors':errors, 'attempts':rows,
            'limitations':['Requested model is registered; actual response model checked where reported.',
                           'Provider-missing usage remains unknown, never zero.', 'Four correlated reconstructed specifications, not original-report heldout evidence.']}

if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--study',type=Path,default=Path(__file__).resolve().parents[1]/'url-repair-study');parser.add_argument('--registration-only',action='store_true');parser.add_argument('--output',type=Path);args=parser.parse_args()
    try: result=validate(args.study,args.registration_only)
    except Exception as exc: result={'valid':False,'errors':[{'check':'study','error':str(exc)}]}
    text=json.dumps(result,indent=2)
    if args.output:args.output.write_text(text+'\n')
    print(text);raise SystemExit(0 if result['valid'] else 1)
