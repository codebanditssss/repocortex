"""Supplemental read-only audit of retained interrupted evidence."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[2];P=R/'work/url-repair-study';D=R/'work/url-repair-recovery'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=load(P/'interruption-recovery.json');a=P/'artifacts/httpx-2694-learned';t=load(a/'transcript-progress.json')
assert r['original_manifest_sha256']==sha(P/'manifest.json')==load(P/'launch.json')['manifest_sha256']
assert r['partial_transcript_sha256']==sha(a/'transcript-progress.json')
assert r['recovery_driver_sha256']==sha(D/'resume_unstarted.py')
for name,h in r['completed_receipt_hashes'].items():assert sha(P/'artifacts'/name/'receipt.json')==h
assert [x['turn'] for x in t[1:]]==list(range(12))
assert len({x['request_id'] for x in t[1:]})==12
assert t[0]['event']=='mandatory_initial_locate'
assert not any(z['name']=='finish' for x in t for z in x.get('tool_results',[]))
assert not (a/'receipt.json').exists() and not (a/'requests.json').exists()
assert not (a/'after-upstream.xml').exists()
assert load(a/'terminal-error.json')['error_type']=='ProcessInterrupted'
edit=load(D/'interrupted-product.json');assert edit['sha256']==sha(D/'interrupted-product.py')==sha(R/edit['path'])
u={'input':sum(x.get('usage',{}).get('prompt_tokens',0) for x in t),'output':sum(x.get('usage',{}).get('completion_tokens',0) for x in t)}
assert u=={'input':139101,'output':6342}
result={'valid':True,'audit_type':'supplemental, after interruption','retained_response_count':12,'known_usage_lower_bound':u,'complete_usage_known':False,'final_tests':'unavailable','original_six_receipts_unchanged':True,'partial_transcript_unchanged':True,'preserved_partial_edit_matches':True,'not_a_completed_repair':True}
(Path(__file__).parent/'interruption-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
