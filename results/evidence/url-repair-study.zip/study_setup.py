"""Offline preparation and immutable registration for the URL repair study."""
from pathlib import Path
import argparse,collections,copy,dataclasses,hashlib,io,json,os,re,subprocess,sys,tarfile,time,zipfile
P=Path(__file__).resolve().parent;R=P.parents[1];D=R/'work/next-repair-design';SOURCE=R/'work/transfer/httpx'
sys.path.insert(0,str(R))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(SOURCE),*args])
def patchid(commit):
 raw=git('show','--pretty=format:','--no-ext-diff',commit)
 return subprocess.check_output(['git','patch-id','--stable'],input=raw).decode().split()[0] if raw.strip() else None
def tokens(s):return set(re.findall(r'[a-z_]{2,}',re.sub(r'#\d+','',s.lower())))
def similarity(a,b):return len(a&b)/len(a|b) if a|b else 1.0
def state(ranker):return {'nodes':ranker.nodes,'edges':[{'key':list(k),**v} for k,v in sorted(ranker.edges.edges.items())],'memory':[{k:(v.tolist() if hasattr(v,'tolist') else v) for k,v in row.items()} for row in ranker.memory]}
def cases_setup(m):
 if (P/'cases.json').exists():return json.loads((P/'cases.json').read_text())
 rows=[r for r in json.loads((D/'screen-results.json').read_text()) if r['status']=='admitted'];cases=[]
 prompts=json.loads((D/'prompt-manifest.json').read_text())
 for row,pm in zip(rows,prompts['records'],strict=True):
  tid='httpx-'+str(row['issue']);assert tid==pm['task_id'];prompt=D/pm['prompt_path'];assert sha(prompt)==pm['prompt_sha256']
  directory=P/'inputs'/tid;directory.mkdir(parents=True,exist_ok=True)
  (directory/'prompt.txt').write_bytes(prompt.read_bytes());patch=D/str(row['issue'])/'upstream-tests.patch';assert sha(patch)==pm['test_patch_sha256'];(directory/'upstream-tests.patch').write_bytes(patch.read_bytes())
  case={'task_id':tid,'issue':row['issue'],'base_commit':row['base_commit'],'fix_commit_evaluator_only':row['commit'],'repository':'https://github.com/encode/httpx','test_modules':row['test_modules'],'expected_case_ids':sorted(row['before']['cases']),'regression_case_ids':row['regression_case_ids'],'env':'venv','prompt_sha256':pm['prompt_sha256']};cases.append(case)
 write(P/'cases.json',cases);return cases

def freeze_sources():
 # Capture all package files, including any untracked Python imports; require clean tracked core.
 revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 dirty=subprocess.check_output(['git','status','--porcelain','--','repocortex','scripts/repair_transport.py'],cwd=R,text=True)
 if dirty.strip():raise RuntimeError('core_source_not_clean')
 files=sorted((R/'repocortex').rglob('*.py'))+[R/'scripts/repair_transport.py']
 hashes={str(f.relative_to(R)):sha(f) for f in files}
 with zipfile.ZipFile(P/'source-before-trial.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in files:z.write(f,str(f.relative_to(R)))
 write(P/'source-freeze.json',{'revision':revision,'captured_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'files':hashes,'archive_sha256':sha(P/'source-before-trial.zip')})

def prepare(m):
 from repocortex.graph.builder import build_graph,iter_sources
 from repocortex.mine.commits import gold_functions_for_commit
 if (P/'manifest.json').exists():raise RuntimeError('already_registered')
 if (P/'preparation.json').exists():raise RuntimeError('already_prepared_use_register')
 cases=cases_setup(m);m.CANDIDATES=cases
 freeze_sources()
 os.environ['HF_HUB_OFFLINE']='1'
 
 if not (P/'venv').exists():(P/'venv').symlink_to(R/'work/repair-study-v2/venv',target_is_directory=True)
 env=subprocess.check_output([str(P/'venv/bin/python'),'-c',"import importlib.metadata as m; print('\\n'.join(sorted(d.metadata['Name']+'=='+d.version for d in m.distributions())))"],text=True);(P/'test-environment.txt').write_text(env)
 (P/'ranker-environment.txt').write_text(subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True))
 excludes={3140,2883,2721,2694,2810,2660,36434};forbidden={patchid(c['fix_commit_evaluator_only']) for c in cases}
 old=json.loads((R/'work/repair-study/candidates.json').read_text())['cases'][:2];forbidden.update(patchid(c['fix_commit_evaluator_only']) for c in old)
 policy={'history_source':'immutable ancestor commit message','order':'newest eligible80 then chronological replay','eligibility':'strict ancestor timestamp before base; fix/fixed/fixes/bug/regression description;1..8mappedfunctions','excludes':sorted(excludes),'patch_ids_excluded':sorted(forbidden),'dedup':'stablepatch/fullnormalizedtext/reference overlap/Jaccard0.8 near descriptions including target specifications','no_target_scoring_until_registration':True}
 write(P/'training-policy.json',policy)
 target_tokens=[tokens((P/'inputs'/c['task_id']/'prompt.txt').read_text()) for c in cases]
 for case in cases:
  tid=case['task_id'];base=case['base_commit'];directory=P/tid
  for arm in ['frozen','learned']:m.archive(base,directory/arm)
  (directory/'prompt.txt').write_bytes((P/'inputs'/tid/'prompt.txt').read_bytes())
  graph=build_graph(iter_sources(directory/'frozen',('httpx',)))
  nodes={uid:{**n.as_row(),'label':n.label} for uid,n in graph.nodes.items()};edges=[{'key':list(k),**e.as_row()} for k,e in graph.edges.items()]
  source_hashes={str(f.relative_to(directory/'frozen')):sha(f) for f in sorted((directory/'frozen').rglob('*')) if f.is_file()}
  write(directory/'base-snapshot.json',{'base_commit':base,'nodes':nodes,'edges':edges,'source_hashes':source_hashes})
  uids={uid for uid,n in graph.nodes.items() if n.label=='Function'};cutoff=int(git('show','-s','--format=%ct',base));rows=[];excluded=[];seenpatch=set();seentext=set();seenrefs=set();cache={};seen_tokens=[]
  for line in git('log','--no-merges','--format=%H%x1f%ct',base+'^').decode().splitlines():
   commit,stamp=line.split('\x1f');stamp=int(stamp)
   if stamp>=cutoff:continue
   message=git('show','-s','--format=%B',commit).decode().strip()
   if not re.search(r'\b(fix|fixed|fixes|bug|regression)\b',message,re.I):continue
   refs=set(map(int,re.findall(r'#(\d+)\b',message)));pid=patchid(commit);normalized=re.sub(r'\s+',' ',message.lower());tok=tokens(message);reason=None
   if refs&excludes:reason='target_reference'
   elif pid in forbidden:reason='target_patch'
   elif pid in seenpatch or normalized in seentext or refs&seenrefs:reason='duplicate'
   elif any(similarity(tok,t)>=0.8 for t in target_tokens+seen_tokens):reason='near_duplicate'
   if reason:excluded.append({'commit':commit,'reason':reason});continue
   gold=gold_functions_for_commit(SOURCE,commit,('httpx',),uids,cache)
   if not gold or len(gold)>8:continue
   rows.append({'commit':commit,'time':stamp,'summary':message.splitlines()[0],'description':'\n'.join(message.splitlines()[1:]),'gold_functions':gold,'patch_id':pid,'references':sorted(refs),'text_source':'immutable_ancestor_commit_message'})
   seenpatch.add(pid);seentext.add(normalized);seenrefs.update(refs);seen_tokens.append(tok)
   if len(rows)==80:break
  rows.sort(key=lambda x:(x['time'],x['commit']))
  for i,row in enumerate(rows):row['ticket']=1000000+i
  if len(rows)<20:raise RuntimeError('history_fewer_than20_no_replacement')
  write(directory/'training.json',{'base_commit':base,'base_timestamp':cutoff,'training':rows,'exclusions':excluded})
  # Reproduce independent baseline and upstream fixed success with exact final environment.
  for phase,commit in [('parent',base),('fixed',case['fix_commit_evaluator_only'])]:
   checkout=directory/('verify-'+phase);m.archive(commit,checkout)
   run=m.ART/(tid+'-admission-'+phase);run.mkdir()
   if phase=='fixed':
    # evaluator applies test patch, so fixed snapshot's tests replaced by base tests first.
    for module in case['test_modules']:(checkout/module).write_bytes(git('show',base+':'+module))
   checks=m.evaluate(case,checkout,run,'verification');write(run/'check.json',checks);c=checks[0]
   if not c['case_set_matches'] or (phase=='parent' and (c['exit_code']!=1 or c['regression_pass'] or not c['guards_pass'])) or (phase=='fixed' and (c['exit_code']!=0 or not c['regression_pass'] or not c['guards_pass'])):raise RuntimeError('baseline_reproduction_failed')
  print('Prepared',tid,'training',len(rows),flush=True)
 write(P/'preparation.json',{'status':'offline_prepared_no_queries_or_paid_calls','tasks':[c['task_id'] for c in cases]})

def validate_history(case):
 data=json.loads((P/case['task_id']/'training.json').read_text());base=case['base_commit'];cutoff=int(git('show','-s','--format=%ct',base));policy=json.loads((P/'training-policy.json').read_text());seen=set();refs=set();texts=[]
 nodes=json.loads((P/case['task_id']/'base-snapshot.json').read_text())['nodes'];cache={}
 from repocortex.mine.commits import gold_functions_for_commit
 for row in data['training']:
  commit=row['commit'];assert subprocess.run(['git','-C',str(SOURCE),'merge-base','--is-ancestor',commit,base]).returncode==0
  assert int(git('show','-s','--format=%ct',commit))==row['time']<cutoff
  message=git('show','-s','--format=%B',commit).decode().strip();assert row['summary']==message.splitlines()[0] and row['description']=='\n'.join(message.splitlines()[1:])
  pid=patchid(commit);assert pid==row['patch_id'] and pid not in seen and pid not in policy['patch_ids_excluded'];seen.add(pid)
  actualrefs=set(map(int,re.findall(r'#(\d+)\b',message)));assert actualrefs==set(row['references']) and not actualrefs&set(policy['excludes']) and not actualrefs&refs;refs.update(actualrefs)
  tok=tokens(message);assert not any(similarity(tok,t)>=0.8 for t in texts);texts.append(tok)
  for c in json.loads((P/'cases.json').read_text()):assert similarity(tok,tokens((P/'inputs'/c['task_id']/'prompt.txt').read_text()))<0.8
  gold=gold_functions_for_commit(SOURCE,commit,('httpx',),{u for u,n in nodes.items() if n['label']=='Function'},cache);assert gold==row['gold_functions']
 assert len(data['training'])>=20
 return len(data['training'])

def make_ranker(base,embedder,dense):
 from repocortex.retrieve.bm25 import BM25Index
 from repocortex.retrieve.frozen import EdgeTable
 from repocortex.retrieve.hybrid import HybridRanker
 nodes=copy.deepcopy(base['nodes']);edges={tuple(e['key']):{k:v for k,v in e.items() if k!='key'} for e in base['edges']}
 return HybridRanker(nodes,EdgeTable(edges),BM25Index.from_nodes(nodes),dense,embedder)

def register(m):
 from repocortex.retrieve.dense import Embedder,build_dense_index
 from repocortex.learn.replay import make_operators,learn_one
 if (P/'manifest.json').exists():raise RuntimeError('already_registered')
 check_sources();cases=json.loads((P/'cases.json').read_text());m.CANDIDATES=cases
 audit={c['task_id']:validate_history(c) for c in cases};write(P/'history-validation.json',audit)
 embedder=Embedder();states={};operators={}
 for case in cases:
  tid=case['task_id'];directory=P/tid;base=json.loads((directory/'base-snapshot.json').read_text());dense=build_dense_index(base['nodes'],embedder,directory/'embeddings.npz');training=json.loads((directory/'training.json').read_text())['training']
  for arm in ['frozen','learned']:
   ranker=make_ranker(base,embedder,dense);episodes=[];totals={}
   if arm=='learned':
    ranker.prepare(training);ops=make_operators(ranker,mode='full',lr=0.25,merger_every=40,decay=0.08)
    for row in training:
     _,results=learn_one(ranker,row,ops);episodes.append({'commit':row['commit'],'results':[dataclasses.asdict(x) for x in results]})
     for result in results:
      total=totals.setdefault(result.name,{'invocations':0,'active_episodes':0,'applied_operations':0});total['invocations']+=1;total['active_episodes']+=int(result.applied>0);total['applied_operations']+=result.applied
   path=directory/(arm+'-state.json');write(path,state(ranker));states[tid+'-'+arm]=sha(path)
   write(directory/(arm+'-operator-audit.json'),{'episodes':episodes,'totals':totals,'memory_count':len(ranker.memory),'node_count':len(ranker.nodes),'edge_count':len(ranker.edges.edges)})
   operators[tid+'-'+arm]=totals
  print('Trained offline',tid,operators[tid+'-learned'],flush=True)
 order=[(c['task_id'],a) for i,c in enumerate(cases) for a in (['frozen','learned'] if i%2==0 else ['learned','frozen'])]
 config={'system':m.SYSTEM,'tools':m.TOOLS+[m.LOCATE],'model':m.MODEL,'temperature':0,'max_tokens_per_call':4096,'budget':m.BUDGET,'order':order,'mandatory_initial_lookup_both_arms':True,'states':states,'query_active_metrics':'allcases; memory similarity>=threshold and selectedtopmemoryk counts; allfunction score/rankchanges; top5intersection; learnedbonus recipients; not selection','stop':'no retry or task replacement; unknown failed usage retained','scope':'four correlated URL tasks; evaluator reconstructed specifications; prior localization exposure'}
 write(P/'config.json',config)
 tracked=[P/'cases.json',P/'training-policy.json',P/'source-freeze.json',P/'source-before-trial.zip',P/'test-environment.txt',P/'ranker-environment.txt',P/'config.json',P/'run_study.py',P/'study_setup.py',P/'sandbox.py',P/'test_sandbox.py',P/'sandbox-tests.log',P/'final-baseline-checks.json',P/'prelaunch-audit.md',P/'prompt-provenance.json']
 tracked+=list((P/'inputs').rglob('*'))
 for c in cases:
  directory=P/c['task_id'];tracked += [x for x in directory.iterdir() if x.is_file()]
 manifest={'schema_version':'url-repair-1','experiment_id':'correlated-url-specification-learning-v1','registered_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'protocol':config,'tasks':cases,'files':{str(x.relative_to(P)):sha(x) for x in tracked if x.is_file()}}
 write(P/'manifest.json',manifest)
 print('REGISTERED no target queries or paid calls yet',flush=True)

def check_sources():
 data=json.loads((P/'source-freeze.json').read_text())
 for path,digest in data['files'].items():assert sha(R/path)==digest,'changed source:'+path

def verify_checkout(case,arm):
 from sandbox import validate_tree
 directory=P/case['task_id'];root=directory/arm;validate_tree(root);expected=json.loads((directory/'base-snapshot.json').read_text())['source_hashes']
 actual={str(f.relative_to(root)):sha(f) for f in root.rglob('*') if f.is_file()}
 assert actual==expected,'checkout differs from exact parent:'+case['task_id']+'-'+arm

def validate_registration():
 manifest=json.loads((P/'manifest.json').read_text());check_sources()
 for path,digest in manifest['files'].items():assert sha(P/path)==digest,'changed registered artifact:'+path
 for c in manifest['tasks']:
  validate_history(c)
  for arm in ['frozen','learned']:verify_checkout(c,arm)
 return manifest

def load_rankers():
 import numpy as np
 from repocortex.retrieve.dense import Embedder,build_dense_index
 embedder=Embedder();out={}
 for c in json.loads((P/'cases.json').read_text()):
  tid=c['task_id'];directory=P/tid;base=json.loads((directory/'base-snapshot.json').read_text());dense=build_dense_index(base['nodes'],embedder,directory/'embeddings.npz');out[tid]={}
  for arm in ['frozen','learned']:
   data=json.loads((directory/(arm+'-state.json')).read_text());ranker=make_ranker(data,embedder,dense)
   ranker.memory=[{**row,'vec':np.asarray(row['vec'],dtype=np.float32)} for row in data['memory']];ranker.rebuild_history();out[tid][arm]=ranker
 return out

def diagnostics(rankers):
 import numpy as np
 from collections import defaultdict
 from repocortex.retrieve.textutil import issue_text
 records=[]
 for tid,arms in rankers.items():
  report=(P/tid/'prompt.txt').read_text();issue={'summary':report,'description':'','ticket':0};preds={a:r.predict(issue,k=r.n) for a,r in arms.items()};f={h.uid:(i,h.score) for i,h in enumerate(preds['frozen'].hits)};l={h.uid:(i,h.score) for i,h in enumerate(preds['learned'].hits)}
  r=arms['learned'];v=r.embedder.encode_one(issue_text(issue));v=v/max(np.linalg.norm(v),1e-12);matrix=r._memory_matrix();sim=matrix@v if matrix is not None else np.array([]);selected=np.argsort(-sim)[:r.memory_k];bm=r._bm25_norm(issue_text(issue),0);base=r.matrix@v+np.float32(r.bm25_mix)*bm;notes=defaultdict(list);used=defaultdict(list)
  memorybonus=r._memory_bonus(v,notes,used,base)
  row={'task':tid,'history_count':len(r.memory),'qualifying_history_count_all':int((sim>=r.memory_thresh).sum()),'qualifying_selected_memory_count':int((sim[selected]>=r.memory_thresh).sum()),'memory_bonus_recipient_count':int(np.count_nonzero(memorybonus)),'changed_score_count':sum(abs(f[u][1]-l[u][1])>1e-9 for u in f),'changed_rank_count':sum(f[u][0]!=l[u][0] for u in f),'positive_learned_score_delta_recipient_count':sum(l[u][1]>f[u][1]+1e-9 for u in f),'top5_overlap_count':len({h.uid for h in preds['frozen'].hits[:5]}&{h.uid for h in preds['learned'].hits[:5]}),'all_scores':{u:{'frozen_rank':f[u][0]+1,'learned_rank':l[u][0]+1,'frozen_score':f[u][1],'learned_score':l[u][1]} for u in f}}
  records.append(row)
 write(P/'query-activity.json',records)
 return records

def cli(m):
 parser=argparse.ArgumentParser();parser.add_argument('action',choices=['prepare','register','validate-registration','run']);args=parser.parse_args();os.environ['HF_HUB_OFFLINE']='1'
 if args.action=='prepare':prepare(m)
 elif args.action=='register':register(m)
 elif args.action=='validate-registration':validate_registration();print('Registration valid')
 else:
  manifest=validate_registration();m.CANDIDATES=manifest['tasks']
  if (P/'launch.json').exists():raise RuntimeError('already_launched_no_retry')
  rankers=load_rankers();diagnostics(rankers)
  write(P/'launch.json',{'started_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'manifest_sha256':sha(P/'manifest.json'),'attempts':8})
  key=json.loads(Path('/home/khushidiwan/Documents/Codex/2026-11-15/https-github-com-hydra-db-selfgraph/work/worker-credentials.json').read_text())['GEMINI_API_KEY'];receipts=[];observations=[]
  for tid,arm in manifest['protocol']['order']:
   check_sources();case=next(c for c in m.CANDIDATES if c['task_id']==tid)
   verify_checkout(case,arm)
   try:receipt,observation=m.run_agent(case,arm,rankers[tid][arm],manifest,key)
   except Exception as exc:
    # Never serialize exception messages: unexpected provider errors might contain credentials.
    receipt={'task_id':tid,'arm':arm,'status':'harness_error','error_type':type(exc).__name__,'no_retry':True,'usage_status':'inspect_retained_partial_requests'}
    observation={'task':tid,'arm':arm,'status':'harness_error','error_type':type(exc).__name__,'compliant_repair':False}
    write(P/'artifacts'/(tid+'-'+arm)/'terminal-error.json',receipt)
   receipts.append(receipt);observations.append(observation);write(P/'receipts.json',{'receipts':receipts});write(P/'observations.json',observations)
  print('All eight attempts completed',flush=True)
