# Independent prelaunch audit

Status: local Codex review completed; Claude review incomplete due provider quota.
Claude read documents, then returned HTTP400 account usage limit (reset reported December1 UTC), without findings/report. Receipt total_cost_usd:0.338278. Its result subtype misleadingly says success; this is not a completed Claude sign-off. No retry or paid repair call was made.

Reviewed execution-protocol.md, prompt manifest/specifications, selection/admission evidence, and the in-progress work/url-repair-study/run_study.py and study_setup.py. Findings sent to prepare worker before launch. This report describes that reviewed draft, not final registration approval.

## Actionable enforcement gaps

1. **Host-executed product code is not filesystem isolated.** Model-facing run_tests executes generated product Python with host-user access. Path filtering on read_file/replace_text and clean subprocess environment do not prevent product code opening sibling evaluator tests/fixed sources, reading files, or mutating nonproduct files. Use real subprocess/container isolation with restricted mounts and networking, or remove run_tests equally before freeze and isolate evaluator execution. Do not claim hidden artifacts are inaccessible without enforcing it.
2. **Validate actual attempt trees.** Registered file hashes cover state/input files but not actual frozen/learned checkout directory content. Compare every initial file against base-snapshot source_hashes immediately before launch/attempt. After execution, reject changed/deleted/added nonproduct files; source patch comparison alone is insufficient.
3. **Retain all scheduled attempt failures.** Unexpected patch/JUnit/evaluator exceptions currently escape the attempt loop, leaving later tasks unattempted and no terminal receipt. Record an explicit failure receipt and continue other scheduled independent attempts; shared registration corruption should fail the launch. No retries or case replacement.

## Sound design choices

Both arms have identical model, tools, mandatory and optional retrieval, code snapshot and budgets, with preregistered counterbalanced order. Historical training is per parent; immutable ancestor commit messages, timestamp checks, target references/patch exclusions and near-duplicate rejection are present. Full histories are frozen before learning. The sampled admission history alone is not treated as final training data. Baseline/fixed tests are rerun before registration. Guard identities derive from parent+upstream-test patch passes, appropriate when requested behavior supersedes historical assertions. Frozen graph/history states and source archives are captured before model calls. Activity diagnostics occur only after registration and cannot select or replace tasks.

All prompts explicitly identify their provenance as evaluator-reconstructed behavioral specifications from upstream regression tests. Therefore the study can compare specification-based repair under these conditions, not original-report generalization. Four same-component tasks and prior localization exposure are correctly disclosed and are not additional launch blockers.

## Registration checks remaining

Re-review the three corrections above; validate final manifest/harness hashes and all actual pristine attempt trees; preserve final environment/source freeze and exact eight-attempt order. No claim of final execution approval until those checks pass. Avoid interpreting active learning operators as repair benefit; retain zero changes and failures.

## Correction review and decision

The preparation worker corrected all three launch gates: bwrap now unshares network/process namespaces and mounts only runtime/dependencies readonly and the selected checkout; evaluator source is readonly with a dedicated writable results mount. Pristine attempt trees are compared to frozen source hashes before launch and each attempt. Nonproduct files are checked after model execution. Unexpected attempt failures produce terminal receipts without selectively retrying or dropping later attempts. Sandbox code and its checks are explicit manifest entries.

Independent negative checks confirmed sibling evaluator/home/credential paths are absent, outbound networking blocked, dependency writes blocked and checkout writes permitted. A further cross-boundary symlink vulnerability was reproduced with a synthetic marker: model code could create a link inside the sandbox which host file tools later followed. The collector now rejects symlinks/special files before tools/evaluator copying, after test execution, before checkout hashing and before reading evaluator results. Independent reproduction confirms the tree validator rejects the link. All three sandbox tests passed locally.

**Decision: GO for offline final baseline verification and registration. No remaining identified design/enforcement blocker after these corrections.** Paid attempts remain conditional on successful final baseline checks and manifest validation with unchanged source/config and all eight pristine checkouts. This is a local independent audit, not a completed Claude audit, and does not establish repair effectiveness.
