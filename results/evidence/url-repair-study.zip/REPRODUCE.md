# Reproduce or inspect the URL repair study

This directory preserves one registered eight-attempt run. Do not rerun in place: `launch.json` intentionally prevents retries. Earlier pilots and their evidence remain unchanged.

Read `manifest.json`, `prompt-provenance.json`, `training-policy.json`, `prelaunch-audit.md` and `source-freeze.json` before interpreting outcomes. Prompts are evaluator-reconstructed behavioral specifications from upstream tests. All four cases concern the same HTTPX URL parser and were previously present in the localization dataset. These are not unseen original reports or independent task families.

The parent-source archives come from `work/transfer/httpx` at the registered base revisions. `inputs/*/upstream-tests.patch` is evaluator-only. The two arms have equal tools, model and budgets; only history-derived state differs. Training uses immutable earlier ancestor commit descriptions, excludes every registered evaluation fix/reference and prior explored HTTPX repair target, and retains duplicate exclusions. Training and serving do not write the production database.

The executed lifecycle was:

```sh
HF_HUB_OFFLINE=1 .venv/bin/python work/url-repair-study/run_study.py prepare
HF_HUB_OFFLINE=1 .venv/bin/python work/url-repair-study/run_study.py register
HF_HUB_OFFLINE=1 .venv/bin/python work/url-repair-study/run_study.py validate-registration
HF_HUB_OFFLINE=1 .venv/bin/python work/url-repair-study/run_study.py run
```

Preparation is offline and registration precedes all target diagnostics and paid calls. Initial preparation found a missing `pip` entry point, then the Python symlink alias mount, then pytest cache writes against read-only evaluator files; all were corrected before registration. Failed preparation artifacts are retained separately or in admission artifact directories. There were no model calls during those failures.

The test runtime is Python3.11 with dependencies listed in `test-environment.txt`. The ranker environment is separately listed. All imported product Python and transport sources are in `source-before-trial.zip`. The cached `sentence-transformers/all-MiniLM-L6-v2` embedding model runs offline. Model weights and virtual environments are not redistributed in the evidence archive. `sandbox.py` requires Linux bubblewrap with unprivileged namespaces; tests execute with no network, no host home, read-only runtime/dependencies and only the individual checkout mounted. Evaluator source is read-only and JUnit output uses a separate results mount. Tree checks reject symlinks and special files at host-access boundaries.

`test_sandbox.py` and the independent auditor's checks verify isolation. Exact upstream parent failures and fixed-revision passes are recorded in `final-baseline-checks.json` and full JUnit logs. Final agent patches run the same upstream-updated modules: the parent-failing cases are regressions, other cases are guards. The optional model test tool runs original parent tests, which can contain superseded assertions; the shared system prompt explains this.

After completion, inspect results without reissuing model calls:

```sh
.venv/bin/python work/url-repair-validation/validate.py --output work/url-repair-validation/outcomes.json
.venv/bin/python work/url-repair-study/publish.py
```

`validate-registration` checks pristine trees and therefore is intended only before execution. The independent outcome validator uses preserved base snapshots and final protected-file hashes after edits. `query-activity.json` retains all function score/rank deltas, including inactive effects; operator audits retain zero activation. `malformed-tool-audit.json`, if present, documents a model argument error without changing the attempt.

GMI provider credentials are intentionally absent from artifacts. Reproduction with new model calls requires a new study directory/registration and an explicitly recorded new run, never overwriting this trial. Current provider behavior may differ; preserve all new outcomes rather than substituting them for these receipts.
