"""Run evaluated code with no network and only checkout + read-only Python runtime."""
from pathlib import Path
import subprocess,os
ROOT=Path(__file__).resolve().parents[2]
ENV=(ROOT/'work/repair-study-v2/venv').resolve()
PYTHON=(ENV/'bin/python').resolve()
RUNTIME=PYTHON.parent.parent
ALIAS=Path(os.readlink(ENV/'bin/python')).parent.parent

def command(checkout,argv,readonly=False,results=None):
 args=['bwrap','--unshare-all','--die-with-parent','--new-session','--clearenv',
 '--ro-bind','/usr','/usr','--ro-bind','/lib64','/lib64',
 '--ro-bind',str(RUNTIME),str(RUNTIME),'--ro-bind',str(RUNTIME),str(ALIAS),'--ro-bind',str(ENV),'/venv',
 '--ro-bind' if readonly else '--bind',str(Path(checkout).resolve()),'/checkout','--proc','/proc','--dev','/dev','--tmpfs','/tmp',
 '--setenv','PATH','/venv/bin:/usr/bin:/bin','--setenv','LANG','C.UTF-8',
 '--setenv','PYTHONDONTWRITEBYTECODE','1','--setenv','PYTEST_DISABLE_PLUGIN_AUTOLOAD','1',
 '--setenv','PYTHONHASHSEED','0','--chdir','/checkout']
 if results is not None:args+=['--bind',str(Path(results).resolve()),'/results']
 return args+['/venv/bin/python',*argv[1:]]

def run(checkout,argv,readonly=False,results=None,**kwargs):
 return subprocess.run(command(checkout,argv,readonly,results),**kwargs)

def validate_tree(checkout):
 import stat
 root=Path(checkout)
 for current,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   mode=(Path(current)/name).lstat().st_mode
   if not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
    raise ValueError('checkout_nonregular_or_symlink')
