"""Supplemental orchestration after process interruption; never retry an attempt."""
import sys,json,hashlib,datetime,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
P=ROOT/'work/url-repair-study'
sys.path.insert(0,str(P));sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts'))
os.environ['HF_HUB_OFFLINE']='1'
import run_study as m
import study_setup as s
manifest=json.loads((P/'manifest.json').read_text());s.check_sources()
for path,digest in manifest['files'].items():
 assert s.sha(P/path)==digest,path
receipts=json.loads((P/'receipts.json').read_text())['receipts']
observations=json.loads((P/'observations.json').read_text())
order=manifest['protocol']['order']
assert len(receipts)==6 and [(r['task_id'],r['arm']) for r in receipts]==[tuple(x) for x in order[:6]]
tid,arm=order[6];assert (tid,arm)==('httpx-2694','learned')
run=P/'artifacts'/f'{tid}-{arm}';partial=run/'transcript-progress.json'
assert partial.exists() and not (run/'receipt.json').exists()
last_tid,last_arm=order[7];assert (last_tid,last_arm)==('httpx-2694','frozen')
assert not (P/'artifacts'/f'{last_tid}-{last_arm}').exists()
case=next(x for x in manifest['tasks'] if x['task_id']==last_tid);s.validate_history(case);s.verify_checkout(case,last_arm)
record={'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Previous collector process absent after session interruption; six terminal receipts and seventh partial transcript retained. No seventh retry. Execute only pristine never-started eighth attempt.','original_manifest_sha256':s.sha(P/'manifest.json'),'partial_transcript_sha256':s.sha(partial),'recovery_driver_sha256':s.sha(Path(__file__)),'completed_receipt_hashes':{r['run_id']:s.sha(P/'artifacts'/r['run_id']/'receipt.json') for r in receipts},'last_durable_turns':len(json.loads(partial.read_text()))-1,'usage_complete':False}
s.write(P/'interruption-recovery.json',record)
receipt={'task_id':tid,'arm':arm,'status':'harness_error','error_type':'ProcessInterrupted','no_retry':True,'usage_status':'incomplete; partial recorded calls retained, in-flight request usage unknown','recovery_record':'interruption-recovery.json'}
s.write(run/'terminal-error.json',receipt);receipts.append(receipt)
observations.append({'task':tid,'arm':arm,'status':'harness_error','error_type':'ProcessInterrupted','compliant_repair':False,'final_evaluation':'unavailable'})
s.write(P/'receipts.json',{'receipts':receipts});s.write(P/'observations.json',observations)
rankers=s.load_rankers()
key=json.loads(Path('/home/khushidiwan/Documents/Codex/2026-11-15/https-github-com-hydra-db-selfgraph/work/worker-credentials.json').read_text())['GEMINI_API_KEY']
try:
 receipt,observation=m.run_agent(case,last_arm,rankers[last_tid][last_arm],manifest,key)
except Exception as exc:
 receipt={'task_id':last_tid,'arm':last_arm,'status':'harness_error','error_type':type(exc).__name__,'no_retry':True,'usage_status':'inspect_retained_partial_requests'}
 observation={'task':last_tid,'arm':last_arm,'status':'harness_error','error_type':type(exc).__name__,'compliant_repair':False}
 s.write(P/'artifacts'/f'{last_tid}-{last_arm}'/'terminal-error.json',receipt)
receipts.append(receipt);observations.append(observation)
s.write(P/'receipts.json',{'receipts':receipts});s.write(P/'observations.json',observations)
print('All eight scheduled outcomes retained; seventh interrupted, eighth executed once.',flush=True)
