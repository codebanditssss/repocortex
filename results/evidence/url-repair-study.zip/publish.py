"""Publish all eight registered attempts after independent validation, never rerun."""
from pathlib import Path
import json,zipfile,hashlib,collections,shutil
P=Path(__file__).resolve().parent;R=P.parents[1]
OUT=Path('/home/khushidiwan/Documents/Codex/2026-11-15/https-github-com-hydra-db-selfgraph/outputs/url-repair-study')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 validation=load(R/'work/url-repair-validation/outcomes.json');assert validation['valid'],validation['errors']
 rows=validation['attempts'];assert len(rows)==8
 observations={(x['task'],x['arm']):x for x in load(P/'observations.json')};activity=load(P/'query-activity.json');manifest=load(P/'manifest.json')
 totals={a:{'raw_repairs':sum(bool(x.get('after',{}).get('all_pass')) for x in rows if x['arm']==a),'compliant_repairs':sum(bool(x['compliant_repair']) for x in rows if x['arm']==a),'scheduled_attempts':4,'terminal_evaluations':sum('after' in x for x in rows if x['arm']==a),'interrupted_attempts':sum(x['status']=='harness_error' for x in rows if x['arm']==a)} for a in ['frozen','learned']}
 summary={'experiment_id':manifest['experiment_id'],'validation':validation,'totals':totals,'activity':[{k:v for k,v in x.items() if k!='all_scores'} for x in activity],'limitations':['Four related URL-parser behavioral specifications, reconstructed by evaluator from upstream regression tests. Not unseen original bug reports.','Original localization dataset previously inspected; these repair attempts are fresh.','Same task component and related chronological history; not independent task families or broad proof.','One attempt per arm; sampling variability and possible pretrained knowledge of historical public fixes remain.','Older failed pilot and two-task studies unchanged.']}
 operator_rows=[];graph_deltas=[]
 for c in manifest['tasks']:
  tid=c['task_id'];op=load(P/tid/'learned-operator-audit.json');operator_rows.append({'task':tid,**op['totals']})
  f=load(P/tid/'frozen-state.json');l=load(P/tid/'learned-state.json');fe={tuple(x['key']):x for x in f['edges']};le={tuple(x['key']):x for x in l['edges']}
  graph_deltas.append({'task':tid,'added_edges':len(le.keys()-fe.keys()),'removed_edges':len(fe.keys()-le.keys()),'modified_edges':sum(fe[k]!=le[k] for k in fe.keys()&le.keys()),'added_nodes':len(set(l['nodes'])-set(f['nodes']))})
 summary['operator_activity']=operator_rows;summary['graph_deltas']=graph_deltas
 partial=load(P/'artifacts/httpx-2694-learned/transcript-progress.json')
 partial_usage={'task':'httpx-2694','arm':'learned','durable_model_responses':len(partial)-1,'known_input_lower_bound':sum(x.get('usage',{}).get('prompt_tokens',0) for x in partial),'known_output_lower_bound':sum(x.get('usage',{}).get('completion_tokens',0) for x in partial),'total_usage_known':False,'final_evaluation':'unavailable'}
 summary['interrupted_attempt_partial_usage']=partial_usage
 summary['limitations'].append('Seventh attempt interrupted after 12 durable responses; no retry, final evaluation unavailable, in-flight and total usage unknown. Four attempts scheduled per arm, only three learned terminal evaluations. Full paired superiority cannot be inferred.')
 summary['estimated_uncached_usage_usd_at_saved_rates']=sum(x.get('known_token_totals',{}).get('prompt_tokens',0)*1e-6+x.get('known_token_totals',{}).get('completion_tokens',0)*6e-6 for x in rows)
 summary['aggregate_usage']={arm:{'known_input':sum(x.get('known_token_totals',{}).get('prompt_tokens',0) for x in rows if x['arm']==arm),'known_output':sum(x.get('known_token_totals',{}).get('completion_tokens',0) for x in rows if x['arm']==arm),'agent_seconds':sum(observations[(x['task'],x['arm'])].get('agent_elapsed_s',0) for x in rows if x['arm']==arm)} for arm in ['frozen','learned']}
 summary['estimated_uncached_usage_usd_at_saved_rates']+=partial_usage['known_input_lower_bound']*1e-6+partial_usage['known_output_lower_bound']*6e-6
 summary['cost_note']='Known-token estimate includes separately reported interrupted-response lower bound; unknown in-flight usage excluded. Not provider billed total or complete cost.'
 summary['aggregate_usage_scope']='Terminal receipts only; interrupted partial usage reported separately. Agent time excludes interruption and is not a complete arm total.'
 lines=['# Correlated URL specification repair study','',f"Eight scheduled attempts, four per arm: verified evaluator passes **{totals['frozen']['raw_repairs']}/4 frozen versus {totals['learned']['raw_repairs']}/4 learned**; budget-compliant repairs **{totals['frozen']['compliant_repairs']}/4 versus {totals['learned']['compliant_repairs']}/4**.",'','The seventh (2694 learned) process was interrupted after 12 durable responses. Its final tests and complete usage are unknown; it was not retried. The eighth, never-started frozen attempt was run once with the original registered harness after hash and pristine-checkout verification. Only three learned attempts have terminal evaluations. Fractions below use all scheduled attempts; an interrupted attempt is not evidence of a failed patch. No complete four-pair superiority claim is supported. Compliant repair requires a completed run, no retained errors, known usage within all budgets, and passing regression plus guard tests. These results describe four related HTTPX URL-parser tasks. They do not establish general improvement. Prompts were explicitly reconstructed by the evaluator from immutable upstream regression tests; original pre-fix issue wording could not be verified. The localization dataset had previously been inspected.','', '| Task | Arm | Regression + guards | Compliant repair | Calls | Known input/output tokens | Agent seconds | Status |','|---|---|---|---|---:|---:|---:|---|']
 for row in rows:
  o=observations[(row['task'],row['arm'])];u=row.get('known_token_totals',{});after=row.get('after',{});tests=f"{after['passed']}/{after['total']} pass" if after else 'unavailable (interrupted)'
  calls=row.get('model_calls','12 durable; total unknown');tokens=f"{u['prompt_tokens']}/{u['completion_tokens']}" if u else f"≥{partial_usage['known_input_lower_bound']}/≥{partial_usage['known_output_lower_bound']} (partial)";seconds=f"{o['agent_elapsed_s']:.1f}" if 'agent_elapsed_s' in o else 'unknown'
  if row.get('unknown_usage'):tokens+=' (lower bound; total unknown)'
  lines.append(f"| {row['task']} | {row['arm']} | {tests} | {row['compliant_repair']} | {calls} | {tokens} | {seconds} | {row.get('classification',row['status'])} |")
 lines+=['','All scheduled attempts used GMI `openai/gpt-5.6-luna`, identical tools and mandatory initial lookup, with 24 calls, 600 seconds, 200k input and 48k output tokens per arm. Historical learned state was the sole intended treatment. No retries or case replacement. Both original sources and evaluator execution were isolated; evaluator tests were mounted read-only. Independent validation checked frozen hashes, ancestry, tool/query equality, usage, protected files and JUnit results.','', '| Task | Prior fixes | Qualifying memory events | Memory recipients | Changed scores / ranks | Top-five overlap |','|---|---:|---:|---:|---:|---:|']
 for a in activity:lines.append(f"| {a['task']} | {a['history_count']} | {a['qualifying_history_count_all']} | {a['memory_bonus_recipient_count']} | {a['changed_score_count']} / {a['changed_rank_count']} | {a['top5_overlap_count']}/5 |")
 lines+=['','Training applied gap ingestion, path compression and edge reweighting in every task. Entity merge/split activated zero times in all four; it was not forced on. Operator invocation, actual applied-operation totals and graph deltas are preserved in the JSON/evidence. Query activity was measured only after registration and never used to select tasks or tune parameters.','', 'Historical descriptions came exclusively from strictly earlier ancestor commit messages with target fixes/references, duplicate patches and near-duplicate descriptions excluded. State histories contained 54/50/48/46 events. All package sources were archived before calls.','', 'Earlier evidence remains unchanged: [original pilot](repair_pilot.md), [frozen-tool follow-up](repair_followup.md), and [two-task learned/frozen study](learning_repair_followup.md). Neither reconstruction nor this correlated sample supports a broad unseen-report claim.','', 'Evidence: `outputs/url-repair-study/evidence.zip`; exact protocol and all eight outcomes retained.']
 lines += ['',f"Known-token usage estimates ${summary['estimated_uncached_usage_usd_at_saved_rates']:.3f} at the saved uncached rates. This is not the provider invoice; caching can reduce cost. This includes the interrupted attempt’s known 139,101 input / 6,342 output token lower bound, reported separately; in-flight usage and final total remain unknown.",'', 'The 2883 learned attempt passed the evaluator but exceeded the input budget (212,464 > 200,000). Its final malformed replace_text call supplied read-file arguments without required old/new strings, producing a retained KeyError. It was not retried.']
 lines += ['', 'The 2694 frozen attempt produced a patch passing all 35 evaluator tests, but request 7 timed out. Its request usage is unknown, it did not finish normally, and the repair is not compliant. The reported 55,848 input / 1,927 output tokens are a lower bound from six returned responses. No retry was made.']
 text='\n'.join(lines)+'\n';OUT.mkdir(parents=True,exist_ok=True)
 for root in [R/'results',OUT]:
  (root/('url_repair_followup.md' if root==R/'results' else 'report.md')).write_text(text);(root/('url_repair_followup.json' if root==R/'results' else 'summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
 shutil.copy2(R/'work/url-repair-validation/outcomes.json',OUT/'independent-validation.json')
 with zipfile.ZipFile(OUT/'evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
  for f in P.rglob('*'):
   if not f.is_file() or f.is_symlink():continue
   rel=f.relative_to(P)
   if any(x in {'venv','__pycache__','.pytest_cache','frozen','learned','verify-parent','verify-fixed'} or x.startswith('evaluate-') for x in rel.parts):continue
   archive.write(f,rel)
  for f in (R/'work/url-repair-recovery').glob('*'):
   if f.is_file():archive.write(f,'supplemental-recovery/'+f.name)
  for f in (R/'work/url-repair-validation').glob('*'):
   if f.is_file():archive.write(f,'independent-validation/'+f.name)
 (OUT/'sha256.json').write_text(json.dumps({f.name:sha(f) for f in OUT.iterdir() if f.is_file() and f.name!='sha256.json'},indent=2)+'\n')
 print(json.dumps(totals));print(OUT)
if __name__=='__main__':main()
